package com.capg;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab7_3 {
	public static List<String> removeElements(List<String> list1, List<String> list3) {
		list1.removeAll(list3);
		return list1;
	}

	public static void main(String args[]) {
		List<String> l1 = new ArrayList<String>();
		List<String> l2 = new ArrayList<String>();
		List<String> l3 = new ArrayList<String>();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter no of elements");
		int n = s.nextInt();
		for (int i1 = 0; i1 < n; i1++) {
			l1.add((String) s.next());
		}
		Scanner s1 = new Scanner(System.in);
		int n1 = s1.nextInt();
		for (int i2 = 0; i2 < n; i2++) {
			l2.add((String) s.next());
		}
		System.out.println(l1);
		System.out.println(l2);
		l3 = removeElements(l1, l2);
		System.out.println(l3);

	}

}
