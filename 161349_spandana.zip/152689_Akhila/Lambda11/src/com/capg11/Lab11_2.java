package com.capg11;

public class Lab11_2 {
	public static void main(String[] args) {
		ILab11_2 lb = (str) -> {
			StringBuffer sb = new StringBuffer(str);
			for (int i = 1; i <= sb.length(); i += 2) {
				sb.insert(i, ' ');
			}
			String str1 = new String(sb);
			return str1;
		};
		System.out.println(lb.stringFormat("Akhila"));
	}
}
