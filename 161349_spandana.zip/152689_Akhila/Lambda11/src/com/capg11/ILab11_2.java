package com.capg11;

public interface ILab11_2 {
public String stringFormat(String str);
}
