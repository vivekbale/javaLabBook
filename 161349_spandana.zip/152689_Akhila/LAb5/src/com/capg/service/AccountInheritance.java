package com.capg.service;

public class AccountInheritance extends Account {
	@Override
	public double deposit(double ammount) {
		balance = balance+ammount;
		return balance;
	}
	@Override
	public void withDraw(double ammount) {
		balance = balance - ammount;
	}

}
