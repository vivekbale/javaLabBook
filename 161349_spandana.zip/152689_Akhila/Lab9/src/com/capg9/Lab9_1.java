package com.capg9;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class Lab9_1 {

	public static void main(String[] args) throws Exception {
		try {
			File source = new File("D:/Source.txt");
			File target = new File("D:/target.txt");

			Scanner content = new Scanner(source);
			PrintWriter pwriter = new PrintWriter(target);
			while (content.hasNextLine()) {
				String s = content.nextLine();
				StringBuffer buffer = new StringBuffer(s);
				buffer = buffer.reverse();
				String rs = buffer.toString();
				pwriter.println(rs);
			}
			content.close();
			pwriter.close();
			System.out.println("File is copied successful!");
		} catch (Exception e) {
			System.err.println("Something went wrong");
		}

	}

}
