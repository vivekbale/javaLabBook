package com.capg9;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Lab9_3 implements Serializable {
	void writedata() {
		Employee db[] = { new Employee("banu", 101, 17092.56f, "analyst"),
				new Employee("uday", 105, 56028.47f, "analyst"), new Employee("akhil", 105, 49028.47f, "analyst") };
		try {
			FileOutputStream fos = new FileOutputStream("D:/employee_Details.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			{
				for (int i = 0; i < db.length; i++) {
					oos.writeObject(db[i]);
				}
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	void readdata() throws FileNotFoundException {
		try {
			FileInputStream fis = new FileInputStream("D:/employee_Details.txt");
			ObjectInputStream sin = new ObjectInputStream(fis);
			{
				Employee e = (Employee) sin.readObject();
				e.showDetails();
				e = (Employee) sin.readObject();
				e.showDetails();
				e = (Employee) sin.readObject();
				e.showDetails();
				sin.close();
			}
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Lab9_3 o = new Lab9_3();
		o.writedata();
		try {
			o.readdata();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
