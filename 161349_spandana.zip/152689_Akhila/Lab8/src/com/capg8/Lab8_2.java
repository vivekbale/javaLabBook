package com.capg8;

import java.util.Date;

public class Lab8_2 implements Runnable {

	public static void main(String[] args) {
		Thread t = new Thread(new Lab8_2());
		t.start();
	}

	@Override
	public void run() {
		try {
			System.out.println("in run");
			for (;;) {
				System.out.println("Timer" + new Date());
				Thread.sleep(10000);
			}
		} catch (Exception e) {
			System.out.println("Error:" + e);
		}
	}
}
