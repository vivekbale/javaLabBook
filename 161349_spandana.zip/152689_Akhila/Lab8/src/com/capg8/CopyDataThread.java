package com.capg8;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class CopyDataThread extends Thread {
FileInputStream fis;
FileOutputStream fos;
public CopyDataThread(FileInputStream fis,FileOutputStream fos) {
	this.fis = fis;
	this.fos = fos;
}
@Override
public void run( ) {
	try {
		int count = 0;
		int i = fis.read();
		count++;
		if(i!=-1) {
			fos.write(i);
			i = fis.read();
			count++;
			if(count == 10) {
				System.out.println("10 characters are copie");
				Thread.sleep(5000);
					count = 0;
				
			}
		}
	}catch(Exception e) {
		System.err.println("Exception :"+e);
	}
}
}
