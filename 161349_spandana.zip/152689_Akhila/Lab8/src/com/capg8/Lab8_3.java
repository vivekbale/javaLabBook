package com.capg8;

import java.util.Random;

public class Lab8_3 extends Thread {
	static int num = 0;

	public void run() {
		try {
			Random random = new Random();
			num = Math.abs(random.nextInt(100));
			System.out.println("number:" + num);
		} catch (Exception e) {
			System.out.println("Error:" + e);
		}
	}

	public static void main(String[] args) {
		Lab8_3 t1 = new Lab8_3();
		t1.start();
		FactThread t2 = new FactThread(num);
		t2.start();
	}
}
