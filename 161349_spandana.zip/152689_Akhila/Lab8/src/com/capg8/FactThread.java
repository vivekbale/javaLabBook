package com.capg8;

public class FactThread {
	int num;

	public FactThread(int num) {
		this.num = num;
	}

	public void run() {
		int fact = 1;
		for (int i = num; i > 1; i--) {
			fact *= i;
		}
		System.out.println("Factorial of" + num + ":" + fact);
	}

	public void start() {
		// TODO Auto-generated method stub

	}

}
